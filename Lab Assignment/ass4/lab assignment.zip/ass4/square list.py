'''
file: square list.py
Author: Trisha Aquino
Description: A lab syntax rules assignment in Object-Oriented course
Version: Oct. 28, 2023
'''

# Put the list of numbers
nums = [2, 5, 6, 8, 11]

# Evaluate the list of squares to all numbers in the nums list
for i in nums:
    print(i ** 2)