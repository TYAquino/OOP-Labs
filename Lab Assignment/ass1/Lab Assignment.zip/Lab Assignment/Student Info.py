''' Program Header
file: Student Info.py
Author: Trisha Aquino
Description: A lab assignment in Object-Oriented course
Version: Sep 22, 2023
'''
print('Welcome!')

# Step 1: get the information of the student
name = input('Please enter your full name: ')
age = input('Age: ')
GPA = input('GPA: ')
major = input('Major: ')
address = input('Address: ')

#Step 2: display the information
print(f'You are {name}, {age} years old, GPA of {GPA}, Majoring in {major}, And you live in the {address}')
