'''
file: Simple Calculator.py
Author: Trisha Aquino
Description: A lab assignment in Object-Oriented course
Version: Oct. 6, 2023
'''

# Step 1 - ask the user for the operation
print('Choose operation:')
print('1. Add \n2. Subtract \n3. Multiply \n4. Divide')

# Step 2 - process the math
resume = 'y'
while resume.lower() == 'y':
    choice = input('Enter choice (1/2/3/4): ')

    num1 = float(input())
    num2 = float(input())

    if choice == '1':
        print(num1, '+', num2, '=', (num1 + num2))
    
    elif choice == '2':
        print(num1, '-', num2, '=', (num1 - num2))
        
    elif choice == '3':
        print(num1, '*', num2, '=', (num1 * num2))

    elif choice == '4':
        print(num1, '/', num2, '=', (num1 / num2))
        
    else:
        print('Invalid input')

# Step 3 - ask the user if they want to calculate again after the process
    resume = input('Do you want another calculation? (y/n): ')
    if resume.lower() == 'n':
        break