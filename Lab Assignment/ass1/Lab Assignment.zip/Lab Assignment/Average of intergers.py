'''
File: Average of integers.py
Author: Trisha Aquino
Description: A lab assignment in Object-Oriented course
Version: Sep 23, 2023
'''

# Step 1: add all the integers
sum = 1 + 2 + 3 + 4 +5

# Step 2: divide the result by 2
average = sum / 5

print(average)